"""Config flow for KeyforSteam integration."""

import logging
import re
import aiohttp
import asyncio
import voluptuous as vol

from homeassistant import config_entries
from homeassistant.core import callback
from homeassistant.helpers.selector import (
    SelectSelector,
    SelectSelectorConfig,
    SelectSelectorMode,
    TextSelector,
    TextSelectorConfig,
    TextSelectorType,
    BooleanSelector,
    BooleanSelectorConfig,
    NumberSelector,
    NumberSelectorConfig,
    NumberSelectorMode,
)

from .const import (
    DOMAIN,
    GAMES_CATALOG_URL,
    CONF_PRODUCT_ID,
    CONF_PRODUCT_NAME,
    CONF_PRODUCT_SLUG,
    CONF_CURRENCY,
    CONF_ALLOW_ACCOUNTS,
    CONF_IGNORE_UNREALISTIC_PRICES,
    CONF_PAYMENT_METHOD,
    CONF_UPDATE_INTERVAL,
    PAYMENT_METHOD_BASE,
    PAYMENT_METHOD_CARD,
    PAYMENT_METHOD_PAYPAL,
    PAYMENT_METHOD_LOWEST_FEES,
    DEFAULT_CURRENCY,
    UPDATE_INTERVAL_HOURS,
    KEYFORSTEAM_PRODUCT_URL,
    ALLKEYSHOP_PRODUCT_URL,
)


def safe_float(value, default=0.0) -> float:
    """Safely convert a value to float, handling None, string, etc."""
    if value is None:
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


_LOGGER = logging.getLogger(__name__)


class KeyforSteamConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):  # type: ignore
    """Handle a config flow for KeyforSteam."""

    VERSION = 1

    def __init__(self):
        """Initialize the config flow."""
        self._games_cache = None
        self._selected_game = None
        self._search_results = []
        self._price_checked = None

    async def _fetch_games_catalog(self):
        """Fetch games catalog from AllKeyShop API."""
        if self._games_cache is not None:
            return self._games_cache

        try:
            async with aiohttp.ClientSession() as session:
                async with asyncio.timeout(30):
                    async with session.get(GAMES_CATALOG_URL) as response:
                        if response.status == 200:
                            data = await response.json()
                            if data.get("status") == "success":
                                self._games_cache = data.get("games", [])
                                _LOGGER.debug(
                                    "Fetched %d games from catalog",
                                    len(self._games_cache),
                                )
                                return self._games_cache
        except Exception as e:
            _LOGGER.error("Error fetching games catalog: %s", e)

        return []

    def _search_games(self, query: str, limit: int = 100) -> list:
        """Search games by name with prioritization."""
        if not self._games_cache or not query:
            return []

        query_lower = query.lower().strip()
        if len(query_lower) < 2:
            return []

        # Scoring:
        # - Exact match: 1000
        # - Starts with: 500
        # - Contains: 100
        # - Penalty for DLC/Account/Pack: -300

        scored_results = []
        for game in self._games_cache:
            name = game.get("name", "")
            name_lower = name.lower()
            score: float = 0

            if name_lower == query_lower:
                score = 1000
            elif name_lower.startswith(query_lower):
                score = 500
            elif query_lower in name_lower:
                score = 100

            if score > 0:
                # Apply penalties to keep base games at top
                if any(
                    word in name_lower
                    for word in ["account", "dlc", "pack", "map", "expansion"]
                ):
                    score -= 300

                # Bonus for shorter names (more likely to be base game)
                score += (200 - min(len(name), 150)) / 10

                scored_results.append((score, game))

        # Sort by score descending
        scored_results.sort(key=lambda x: x[0], reverse=True)

        return [item[1] for item in scored_results[:limit]]

    def _create_slug(self, game_name: str) -> str:
        """Create URL slug from game name."""
        slug = game_name.lower()
        slug = re.sub(r"[^a-z0-9]+", "-", slug)
        slug = slug.strip("-")
        return slug

    async def _check_game_has_prices(
        self,
        slug: str,
        currency: str,
        allow_accounts: bool,
        payment_method: str,
        ignore_unrealistic: bool,
    ) -> bool:
        """Check if the game has any active price listings."""
        if currency == "eur":
            url = KEYFORSTEAM_PRODUCT_URL.format(slug=slug)
        else:
            url = ALLKEYSHOP_PRODUCT_URL.format(slug=slug)

        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7",
        }

        try:
            async with aiohttp.ClientSession() as session:
                async with asyncio.timeout(15):
                    async with session.get(url, headers=headers) as response:
                        if response.status != 200:
                            return False
                        html = await response.text()

                        # Use regex to find gamePageTrans
                        match = re.search(
                            r"var gamePageTrans\s*=\s*(\{.*?\});", html, re.DOTALL
                        )
                        if match:
                            import json

                            game_data = json.loads(match.group(1))
                            prices = game_data.get("prices", [])
                            valid_prices = []
                            for p in prices:
                                if not allow_accounts and p.get("account"):
                                    continue

                                # Select price based on payment method
                                price_val = safe_float(p.get("price"))
                                if payment_method == PAYMENT_METHOD_CARD:
                                    price_val = safe_float(
                                        p.get("priceCard")
                                    ) or safe_float(p.get("price"))
                                elif payment_method == PAYMENT_METHOD_PAYPAL:
                                    price_val = safe_float(
                                        p.get("pricePaypal")
                                    ) or safe_float(p.get("price"))
                                elif payment_method == PAYMENT_METHOD_LOWEST_FEES:
                                    price_fields = []
                                    if p.get("priceCard") is not None:
                                        card_price = safe_float(p.get("priceCard"))
                                        if card_price > 0:
                                            price_fields.append(card_price)
                                    if p.get("pricePaypal") is not None:
                                        paypal_price = safe_float(p.get("pricePaypal"))
                                        if paypal_price > 0:
                                            price_fields.append(paypal_price)
                                    if price_fields:
                                        price_val = min(price_fields)
                                    else:
                                        price_val = safe_float(p.get("price"))

                                if price_val <= 0:
                                    continue
                                valid_prices.append(price_val)

                            if valid_prices:
                                valid_prices.sort()
                                if ignore_unrealistic:
                                    valid_prices = [
                                        v for v in valid_prices if v >= 0.80
                                    ]
                                    if len(valid_prices) >= 2:
                                        p1 = valid_prices[0]
                                        p2 = valid_prices[1]
                                        if (p2 - p1) / p2 >= 0.70:
                                            valid_prices.pop(0)
                                return len(valid_prices) > 0
        except Exception as e:
            _LOGGER.error("Error checking game prices in config flow: %s", e)
        return False

    async def async_step_user(self, user_input=None):
        """Handle the initial step - game search."""
        errors = {}

        # Fetch games catalog in background
        if self._games_cache is None:
            await self._fetch_games_catalog()

        if user_input is not None:
            game_query = user_input.get("game_query", "").strip()

            if game_query:
                # Search for games
                results = self._search_games(game_query)

                if results:
                    # Store results and move to selection step
                    self._search_results = results
                    return await self.async_step_select()
                else:
                    errors["game_query"] = "no_games_found"
            else:
                errors["game_query"] = "required"

        return self.async_show_form(
            step_id="user",
            data_schema=vol.Schema(
                {
                    vol.Required("game_query"): TextSelector(
                        TextSelectorConfig(type=TextSelectorType.TEXT)
                    ),
                }
            ),
            errors=errors,
            description_placeholders={
                "games_count": str(len(self._games_cache)) if self._games_cache else "0"
            },
        )

    async def async_step_select(self, user_input=None):
        """Handle game selection step."""
        errors = {}

        if user_input is not None:
            selected_id = user_input.get("game_selection")
            currency = user_input.get(CONF_CURRENCY, DEFAULT_CURRENCY)
            allow_accounts = user_input.get(CONF_ALLOW_ACCOUNTS, False)
            ignore_unrealistic = user_input.get(CONF_IGNORE_UNREALISTIC_PRICES, True)
            payment_method = user_input.get(
                CONF_PAYMENT_METHOD, PAYMENT_METHOD_LOWEST_FEES
            )

            # Find selected game
            selected_game = None
            for game in self._search_results:
                if str(game.get("id")) == str(selected_id):
                    selected_game = game
                    break

            if selected_game:
                game_name = selected_game.get("name", "Unknown Game")
                game_id = selected_game.get("id")
                game_slug = self._create_slug(game_name)

                # Check if already configured
                await self.async_set_unique_id(f"keyforsteam_{game_id}")
                self._abort_if_unique_id_configured()

                # Check if we need to show the price warning
                if getattr(self, "_price_checked", None) != game_id:
                    has_prices = await self._check_game_has_prices(
                        game_slug,
                        currency,
                        allow_accounts,
                        payment_method,
                        ignore_unrealistic,
                    )
                    if not has_prices:
                        self._price_checked = game_id
                        errors["base"] = "no_prices_warning"

                if not errors:
                    return self.async_create_entry(
                        title=game_name,
                        data={
                            CONF_PRODUCT_ID: str(game_id),
                            CONF_PRODUCT_NAME: game_name,
                            CONF_PRODUCT_SLUG: game_slug,
                            CONF_CURRENCY: currency,
                            CONF_ALLOW_ACCOUNTS: allow_accounts,
                            CONF_IGNORE_UNREALISTIC_PRICES: ignore_unrealistic,
                            CONF_PAYMENT_METHOD: payment_method,
                        },
                    )
            else:
                errors["game_selection"] = "invalid_selection"

        # Build selection options
        options = [
            {"value": str(game.get("id")), "label": game.get("name", "Unknown")}
            for game in self._search_results
        ]

        return self.async_show_form(
            step_id="select",
            data_schema=vol.Schema(
                {
                    vol.Required("game_selection"): SelectSelector(
                        SelectSelectorConfig(
                            options=options,
                            mode=SelectSelectorMode.DROPDOWN,
                        )
                    ),
                    vol.Required(
                        CONF_CURRENCY, default=DEFAULT_CURRENCY
                    ): SelectSelector(
                        SelectSelectorConfig(
                            options=[
                                {"value": "eur", "label": "EUR (€)"},
                                {"value": "usd", "label": "USD ($)"},
                                {"value": "gbp", "label": "GBP (£)"},
                            ],
                            mode=SelectSelectorMode.DROPDOWN,
                        )
                    ),
                    vol.Optional(CONF_ALLOW_ACCOUNTS, default=False): BooleanSelector(
                        BooleanSelectorConfig()
                    ),
                    vol.Optional(
                        CONF_IGNORE_UNREALISTIC_PRICES, default=True
                    ): BooleanSelector(BooleanSelectorConfig()),
                    vol.Required(
                        CONF_PAYMENT_METHOD, default=PAYMENT_METHOD_LOWEST_FEES
                    ): SelectSelector(
                        SelectSelectorConfig(
                            options=[
                                {"value": PAYMENT_METHOD_BASE, "label": "base"},
                                {"value": PAYMENT_METHOD_CARD, "label": "card"},
                                {"value": PAYMENT_METHOD_PAYPAL, "label": "paypal"},
                                {
                                    "value": PAYMENT_METHOD_LOWEST_FEES,
                                    "label": "lowest_fees",
                                },
                            ],
                            mode=SelectSelectorMode.DROPDOWN,
                            translation_key="payment_method",
                        )
                    ),
                }
            ),
            errors=errors,
        )

    @staticmethod
    @callback
    def async_get_options_flow(config_entry):
        """Get the options flow for this handler."""
        return KeyforSteamOptionsFlow(config_entry)


class KeyforSteamOptionsFlow(config_entries.OptionsFlow):
    """Handle options flow for KeyforSteam."""

    def __init__(self, config_entry: config_entries.ConfigEntry) -> None:
        """Initialize options flow."""
        super().__init__()
        self._config_entry = config_entry

    async def async_step_init(self, user_input=None):
        """Handle options flow."""
        if user_input is not None:
            return self.async_create_entry(title="", data=user_input)

        # Get current values from options or data
        options = self.config_entry.options
        data = self.config_entry.data

        current_currency = options.get(
            CONF_CURRENCY, data.get(CONF_CURRENCY, DEFAULT_CURRENCY)
        )
        current_allow_accounts = options.get(
            CONF_ALLOW_ACCOUNTS, data.get(CONF_ALLOW_ACCOUNTS, False)
        )
        current_ignore_unrealistic = options.get(
            CONF_IGNORE_UNREALISTIC_PRICES,
            data.get(CONF_IGNORE_UNREALISTIC_PRICES, True),
        )
        current_payment_method = options.get(
            CONF_PAYMENT_METHOD,
            data.get(CONF_PAYMENT_METHOD, PAYMENT_METHOD_LOWEST_FEES),
        )
        current_update_interval = options.get(
            CONF_UPDATE_INTERVAL, data.get(CONF_UPDATE_INTERVAL, UPDATE_INTERVAL_HOURS)
        )

        return self.async_show_form(
            step_id="init",
            data_schema=vol.Schema(
                {
                    vol.Optional(
                        CONF_CURRENCY, default=current_currency
                    ): SelectSelector(
                        SelectSelectorConfig(
                            options=[
                                {"value": "eur", "label": "EUR (€)"},
                                {"value": "usd", "label": "USD ($)"},
                                {"value": "gbp", "label": "GBP (£)"},
                            ],
                            mode=SelectSelectorMode.DROPDOWN,
                        )
                    ),
                    vol.Optional(
                        CONF_ALLOW_ACCOUNTS, default=current_allow_accounts
                    ): BooleanSelector(BooleanSelectorConfig()),
                    vol.Optional(
                        CONF_IGNORE_UNREALISTIC_PRICES,
                        default=current_ignore_unrealistic,
                    ): BooleanSelector(BooleanSelectorConfig()),
                    vol.Optional(
                        CONF_PAYMENT_METHOD, default=current_payment_method
                    ): SelectSelector(
                        SelectSelectorConfig(
                            options=[
                                {"value": PAYMENT_METHOD_BASE, "label": "base"},
                                {"value": PAYMENT_METHOD_CARD, "label": "card"},
                                {"value": PAYMENT_METHOD_PAYPAL, "label": "paypal"},
                                {
                                    "value": PAYMENT_METHOD_LOWEST_FEES,
                                    "label": "lowest_fees",
                                },
                            ],
                            mode=SelectSelectorMode.DROPDOWN,
                            translation_key="payment_method",
                        )
                    ),
                    vol.Optional(
                        CONF_UPDATE_INTERVAL, default=int(current_update_interval)
                    ): NumberSelector(
                        NumberSelectorConfig(
                            min=1,
                            max=24,
                            step=1,
                            mode=NumberSelectorMode.BOX,
                            unit_of_measurement="h",
                        )
                    ),
                }
            ),
        )
